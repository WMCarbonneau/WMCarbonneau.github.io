#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

char* MakeStringInHeap();
int*  AllocStringInHeap();

int main(int argc, char **argv) {
    if (argc < 3) {printf("Program requires 2 positional arguments (String/Rotation number). Exiting"); exit(1);} 
    if (argc > 3) {printf("\nI can't believe you used more than two arguments... Why? \n");}
    if ( atoi(argv[2]) > 25 || atoi(argv[2]) < 1) {printf("Program requires one more positional argument (Rotation number) between 1 and 25 (1-25). Exiting"); exit(1);}
    int i;
    int rotnum = atoi(argv[2]);
    int *buff = AllocStringInHeap(argv[1]); // make buffer array in heap
    for (i = 0; i < strlen(argv[1]); i++) {

        // switch case using GNU compiler range function

        int temp = argv[1][i]; // convert to ascii characters
        switch (temp) {
            case 'A' ... 'Z':
                temp += rotnum; // rotate letter by rotnum
                if (temp > 90) {temp -= 26;} // roll around z
                buff[i] = temp;
                break;
            case 'a' ... 'z':
                temp += rotnum; // rotate letter by rotnum
                if (temp > 122) {temp -= 26;} // roll around z
                buff[i] = temp;
                break;
            default:
                buff[i] = temp;
                break;
        }
        // Compare to find letter characters
        /*if (temp >= 97 && temp <= 122) { // lowercase
            temp += rotnum; // rotate letter by rotnum
            if (temp > 122) {temp -= 26;} // roll around z
            buff[i] = temp; // add to buffer array

        } else if (temp >= 65 && temp <= 90){ // UPPERCASE
            temp += rotnum; // rotate letter by rotnum
            if (temp > 90) {temp -= 26;} // roll around z
            buff[i] = temp; // add to buffer array
        }else if (temp < 65 || temp > 122){buff[i] = temp;}*/
    }    

    printf("\nOutput: ");
    for (i = 0; i < strlen(argv[1]); i++){printf("%c", buff[i]);} // Print buffer array
    printf("\n\nKey: %d\n ", rotnum);
    free(buff);
    return 0;
 }

 /*
Takes a c string as input, and allocates the length of that string
in the heap. The caller takes over ownership of the new array
and is responsible for freeing it.
*/

int* AllocStringInHeap(const char* source) {
    int* newString;
    newString = (int*) malloc(strlen(source));
    assert(newString != NULL);
    return(newString);
}