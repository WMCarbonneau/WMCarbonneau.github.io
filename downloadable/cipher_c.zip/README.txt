This program must be run via the command line using:

./cipher.exe "Text to encrypt" 5

'5' may be any number: 2-25