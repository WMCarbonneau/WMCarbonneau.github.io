#!/bin/sh
python3 Main.py