from random import randint
from tkinter import Tk, Label, Button, Entry


def diceroll(minimum, maximum):
    return randint(minimum, maximum)


class MainGui:
    def __init__(self, master):
        self.master = master
        master.title("Diceroll")
        master.configure(bg="#00bae9")
        master.geometry("280x130")

        self.label1 = Label(master, text="Insert minimum dice number...", bg="#00bae9")
        self.label1.grid(row=1, column=0, sticky="")
        self.Entry = Entry(master)
        self.Entry.grid(row=2, column=0, sticky="")
        self.label2 = Label(master, text="Insert maximum dice number...", bg="#00bae9")
        self.label2.grid(row=3, column=0, sticky="")
        self.Entry1 = Entry(master)
        self.Entry1.grid(row=4, column=0, sticky="")
        self.roll_button = Button(master, text="Dice Roll", command=self.roll)
        self.roll_button.grid(row=1, column=5, sticky="")
        self.label3 = Label(master, text="Number Output", bg="#00bae9")
        self.label3.grid(row=2, column=5, sticky="W")
        self.close_button = Button(master, text="Close", command=master.quit)
        self.close_button.grid(row=4, column=5, sticky="")
        master.bind("<Return>", self.roll)

    def roll(self, _event=None):
        if self.Entry.get() and self.Entry1.get() != "":
            try:
                i = int(self.Entry.get())
                o = int(self.Entry1.get())
            except ValueError:
                pass
            else:
                if int(self.Entry.get()) < int(self.Entry1.get()):
                    result = diceroll(int(self.Entry.get()), int(self.Entry1.get()))
                    print(result)
                    self.label3.config(text=result)


root = Tk()
my_gui = MainGui(root)
root.mainloop()
